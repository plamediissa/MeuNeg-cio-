# MeuNegócio
App de gestão de lojas e serviços pronto para Android Studio.